<?php
/**
 * Copyright (C) 2014-2026 Amarta Dey
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.

 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Kangaroos cannot jump here' );
}
?>

<div class="ai1wm-message ai1wm-red-message ai1wm-clear" style="margin-top: 4em;">
	<?php
	printf(
		__(
			'<h3>Site could not be restored</h3>' .
			'<p>Please make sure that storage directory <strong>%s</strong> has read and write permissions.</p>',
			AI1WM_PLUGIN_NAME
		),
		AI1WM_BACKUPS_PATH
	);
	?>
</div>
